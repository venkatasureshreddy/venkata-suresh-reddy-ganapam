INSERT INTO MELD_PROGRAM_NM
(PROGRAM_ID
,NAME
,DESCR
,CONTACT_GROUP_ID
,PARENT_ID
,ACTIVE_IND
,AUD_CREATE_DT
,AUD_CREATE_USER
,AUD_MODIFY_DT
,AUD_MODIFY_USER
,CLUSTER_ID
,WF_JOB_NAME
,GROUP_NAME
,APP_NAME
,MONITOR_STATUS_ID)
VALUES (MELD_PROGRAM_NM_SEQ.nextval
,'DIGITAL HTTP RAW EVENTS'
,'Parent for the DIGITAL HTTP RAW EVENTS'
,(select contact_group_id from job_control.meld_program_contact_groups where lower(group_name) like '%meld%vi%' and rownum = 1)
,NULL
,1
,sysdate
,'JOB_CONTROL'
,sysdate
,'JOB_CONTROL'
,1
,null
,'MELD_VIEWING_INSIGHTS'
,'DIGITAL_HTTP_RAW_EVENTS_CORE'
,1);
commit;
---------------------------

INSERT INTO MELD_PROGRAM_NM
(PROGRAM_ID
,NAME
,DESCR
,CONTACT_GROUP_ID
,PARENT_ID
,ACTIVE_IND
,AUD_CREATE_DT
,AUD_CREATE_USER
,AUD_MODIFY_DT
,AUD_MODIFY_USER
,CLUSTER_ID
,WF_JOB_NAME
,GROUP_NAME
,APP_NAME
,MONITOR_STATUS_ID
,SLA_INTERNAL_ET
,SLA_EXTERNAL_ET
,SLA_INTERNAL_CONTACT_GROUP_ID
,SLA_EXTERNAL_CONTACT_GROUP_ID
,PLAN_SCHED_TIME
,PLAN_FREQ
,MP_URL)
VALUES (MELD_PROGRAM_NM_SEQ.nextval
,'DIGITAL_HTTP_RAW_EVENTS_PURGE'
,'Purge HTTP raw events files for digital http'
,(select contact_group_id from job_control.meld_program_contact_groups where lower(group_name) like '%meld%vi%' and rownum = 1)
,(select program_id from job_control.meld_program_nm where name = 'DIGITAL HTTP RAW EVENTS' and rownum = 1)
,1
,sysdate
,'JOB_CONTROL'
,sysdate
,'JOB_CONTROL'
,1
,'PURGE.SRC.HTTP.RAW.EVENTS'
,'MELD_VIEWING_INSIGHTS'
,'DIGITAL_HTTP_RAW_EVENTS_PURGE'
,1
,'01:00'
,'02:00'
,(select contact_group_id from job_control.meld_program_contact_groups where lower(group_name) like '%meld%vi%' and rownum = 1)
,(select contact_group_id from job_control.meld_program_contact_groups where lower(group_name) like '%meld%vi%' and rownum = 1)
,'01:00'
,'D'
,'https://wiki.sys.comcast.net/display/dataBig/Digital+Http+Raw+Events');
commit;
-----------------------------------------------------

INSERT INTO MELD_PROGRAM_NM
(PROGRAM_ID
,NAME
,DESCR
,CONTACT_GROUP_ID
,PARENT_ID
,ACTIVE_IND
,AUD_CREATE_DT
,AUD_CREATE_USER
,AUD_MODIFY_DT
,AUD_MODIFY_USER
,CLUSTER_ID
,WF_JOB_NAME
,GROUP_NAME
,APP_NAME
,MONITOR_STATUS_ID
,SLA_INTERNAL_ET
,SLA_EXTERNAL_ET
,SLA_INTERNAL_CONTACT_GROUP_ID
,SLA_EXTERNAL_CONTACT_GROUP_ID
,PLAN_SCHED_TIME
,PLAN_FREQ
,MP_URL)
VALUES (MELD_PROGRAM_NM_SEQ.nextval
,'DIGITAL_HTTP_RAW_EVENTS_DQ_CHECK'
,'Workflow for Checking DQ of Digital Http raw events'
,(select contact_group_id from job_control.meld_program_contact_groups where lower(group_name) like '%meld%vi%' and rownum = 1)
,(select program_id from job_control.meld_program_nm where name = 'DIGITAL HTTP RAW EVENTS' and rownum = 1)
,1
,sysdate
,'JOB_CONTROL'
,sysdate
,'JOB_CONTROL'
,1
,'DIGITAL.HTTP.STREAMING.RAWEVENTS.DQ_CHECK'
,'MELD_VIEWING_INSIGHTS'
,'DIGITAL.HTTP.STREAMING.RAWEVENTS.DQ_CHECK'
,1
,'08:00'
,'16:00'
,(select contact_group_id from job_control.meld_program_contact_groups where lower(group_name) like '%meld%vi%' and rownum = 1)
,(select contact_group_id from job_control.meld_program_contact_groups where lower(group_name) like '%meld%vi%' and rownum = 1)
,'00:05'
,'H'
,'https://wiki.sys.comcast.net/display/dataBig/Digital+Http+Raw+Events');
commit;
exit