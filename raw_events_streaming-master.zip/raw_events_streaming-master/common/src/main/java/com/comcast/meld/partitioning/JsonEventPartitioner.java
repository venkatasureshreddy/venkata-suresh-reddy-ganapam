package com.comcast.meld.partitioning;

import gobblin.configuration.State;
import gobblin.writer.partitioner.WriterPartitioner;
import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.log4j.Logger;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This process iterates for every record in the kafka topic takes event name
 * and event time stamp from the record to generate corresponding day_id
 * partition records are of the format of json_object_name { json }
 * 
 * @author mfagan201
 *
 */

@SuppressWarnings("rawtypes")
public class JsonEventPartitioner implements WriterPartitioner {
  private static final String NAMESPACE = "gobblin.extract.kafka";


	private static final Logger LOG = Logger.getLogger(JsonEventPartitioner.class);
	public static final String DAY_ID = "day_id";
	public static final String JSON_OBJECT = "json_object";
	public static final String MALFORMED_TIME="malformed_time";
  private static final String INVALID_MESSAGE="invalid_message";
	private static final Pattern JSON_NAME_PATTERN = Pattern.compile("^\\s*(.*)\\s*([{](.*)[}])");
  private static final Pattern JSON_TIME_PATTERN = Pattern.compile("['\"]@timestamp['\"]:['\"](.*)['\"]");

	private static final Schema SCHEMA = SchemaBuilder.record("Partitioning").namespace(NAMESPACE) .fields()
			.name(JSON_OBJECT).type(Schema.create(Schema.Type.STRING)).noDefault()
			.name(DAY_ID) .type(Schema.create(Schema.Type.STRING)).noDefault()
			.endRecord();

	public JsonEventPartitioner() {
	}

	public JsonEventPartitioner(State state, int numBranches, int branchId) {
		this();
	}

	@Override
	// generate a record with event name and the day_id
	public GenericRecord partitionForRecord(Object message) {

		GenericRecord partition = new GenericData.Record(SCHEMA);
		String body;

		if ( message instanceof byte[] ) {
			body = new String((byte[]) message);
		} else  {
      LOG.warn("Cannot convert byte array to string:" + message);
			partition.put(JSON_OBJECT, INVALID_MESSAGE);
			partition.put(DAY_ID, MALFORMED_TIME);
			return partition;
		}

		try {
		  Matcher jMatch = JSON_NAME_PATTERN.matcher(body);
      if (jMatch.find()) {
        String jsonName = jMatch.group(1 );
        String jsonObject = jMatch.group(2);
        partition.put(JSON_OBJECT, jsonName);
        Matcher tMatch = JSON_TIME_PATTERN.matcher(jsonObject);
        if ( tMatch.find()) {
          String timestamp = tMatch.group(1);
          partition.put(DAY_ID, getDayId(timestamp));
        }
        else {
          partition.put(DAY_ID, MALFORMED_TIME);
        }
      } else {
         partition.put(JSON_OBJECT, INVALID_MESSAGE);
         partition.put(DAY_ID, MALFORMED_TIME);
      }
		} catch (IllegalStateException | IndexOutOfBoundsException e) {
			LOG.warn("Event name column has NULL value and process this event" + "as invalid_event -- " + body);
			LOG.error(e.getLocalizedMessage(), e);
      partition.put(JSON_OBJECT, INVALID_MESSAGE);
      partition.put(DAY_ID, MALFORMED_TIME);
		}
    return partition;
	}

	@Override
	public Schema partitionSchema() {
		return SCHEMA;
	}

	// getting day_id for the corresponding timeStamp
  // timestamp is of the format "2016-11-09T17:49:41.841Z"  return just the date portion or "2016-11-09"
	private static String getDayId(String timestamp) {
	    String result = MALFORMED_TIME;
      if ( timestamp != null ) {
        int datepos = timestamp.indexOf('T');
        if  (datepos > 0 ) {
          result = "day_id=" + timestamp.substring(0, datepos);
        }
      }
			return result;
		}
}
