package com.comcast.meld.fork;

import gobblin.fork.CopyNotSupportedException;
import gobblin.fork.Copyable;

public class CopyableSchema implements Copyable<String> {
    private final String record;

    public CopyableSchema(String record) {
        this.record = record;
    }

    @Override
    public String copy()
            throws CopyNotSupportedException {
        if (!(this.record instanceof String)) {
            throw new CopyNotSupportedException(
                    "The record to make copy is not an instance of " + String.class.getName());
        }
        // Make a deep copy of the original record
        return record;
    }
}
