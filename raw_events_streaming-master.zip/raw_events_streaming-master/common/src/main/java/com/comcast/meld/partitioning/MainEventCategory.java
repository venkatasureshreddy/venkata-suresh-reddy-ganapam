package com.comcast.meld.partitioning;

public enum MainEventCategory implements EventCategory {

    A(16, "ad_display"),
    B(23, "button_configuration"),
    C(22, "channel_change_verbose"),
    E(31, "program_event"),
    F(17, "favorite_channel"),
    G(15, "vod_category"),
    I(19, "information_screen"),
    K(15, "key_press"),
    M(17, "missing_data"),
    P(15, "pulse"),
    R(15, "reset"),
    S(21, "state_change"),
    T(15, "turbo_key"),
    U(29, "unit_identification"),
    V(19, "video_playback_session"),
    Z(17, "menu_configuration"),
    c(18, "channel_change_brief"),
    L(20, "parent_lock"),
    X(0, "", true),
    TS(18, "transaction_summary"),
    O(16, "setup_option"),
    H(0, "", true);

    private final int checkLength;
    private final String eventType;
    private final boolean isChildPresent;

    MainEventCategory(final int checkLength, final String eventType, final boolean isChildPresent) {
        this.checkLength = checkLength;
        this.eventType = eventType;
        this.isChildPresent = isChildPresent;
    }

    MainEventCategory(final int checkLength, final String eventType) {
        this(checkLength, eventType, false);
    }

    @Override
    public int checkLength() {
        return checkLength;
    }

    @Override
    public String getEventType() {
        return eventType;
    }

    public EventCategory getEventCategory(final String childEvent) {
        if (isChildPresent) {
            return SubEventCategory.getChildEventCategory(this, childEvent);
        } else {
            return this;
        }
    }
}
