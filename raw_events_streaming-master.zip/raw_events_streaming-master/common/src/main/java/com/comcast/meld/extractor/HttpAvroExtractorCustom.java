package com.comcast.meld.extractor;

import gobblin.configuration.WorkUnitState;
import gobblin.source.extractor.DataRecordException;
import gobblin.source.extractor.extract.kafka.KafkaAvroExtractor;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.*;
import org.apache.log4j.Logger;

import com.google.common.base.Optional;

import java.io.IOException;

/**
 * Created by bowenzheng on 8/22/17.
 */
public class HttpAvroExtractorCustom extends KafkaAvroExtractor{

    private static final org.apache.log4j.Logger LOG = Logger.getLogger(HttpAvroExtractorCustom.class);

    public HttpAvroExtractorCustom(WorkUnitState state) {

        super(state);


    }


    @Override

    protected Schema getRecordSchema(byte[] payload) {

        Schema schema = null;

        try {
            schema = new Schema.Parser().parse(ClassLoader.getSystemResourceAsStream(("digital_http.avsc")));
        } catch (Exception e) {
            LOG.error("Error parsing voice command avsc" + e.getMessage());
        }

        return schema;

    }

    @Override

    protected Decoder getDecoder(byte[] payload) {

       // LOG.info(" !!! Inside getDecoder !!! " + payload);

        Decoder decoder = DecoderFactory.get().binaryDecoder(payload, null);

       // LOG.info(" !!! Decoder returned is  !!! " + decoder.toString());

        return decoder;

    }


    @Override
    protected Schema getLatestSchemaByTopic(String topic) {

        Schema schema = null;

        try {
            LOG.info(" !!! Inside getLatestSchemaByTopic !!! ");
            schema = new Schema.Parser().parse(ClassLoader.getSystemResourceAsStream(("digital_http.avsc")));
            LOG.info(" !!! Schema is  !!! " + schema.toString() );
        } catch (Exception e) {
            LOG.error("Error parsing voice command avsc" + e.getMessage());
        }
        return schema;

    }

    @Override
    protected Optional<Schema> getExtractorSchema() {

        Schema schema = null;

        try {
            LOG.info(" !!! Inside getExtractorSchema !!! ");
            schema = new Schema.Parser().parse(ClassLoader.getSystemResourceAsStream(("digital_http.avsc")));
            LOG.info(" !!! Schema is  !!! " + schema.toString() );
        } catch (Exception e) {
            LOG.error("Error parsing voice command avsc" + e.getMessage());
        }

        return Optional.fromNullable(schema);
    }

    @Override
    public GenericRecord readRecordImpl(GenericRecord reuse) throws DataRecordException, IOException {
       // LOG.info (" !!! Inside readRecordImpl !!!" + (GenericRecord)super.readRecordImpl(reuse)) ;
        return (GenericRecord)super.readRecordImpl(reuse);
    }
}
