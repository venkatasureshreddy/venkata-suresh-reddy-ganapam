package com.comcast.meld.generator;

import com.comcast.meld.schema.TrickPlayAndTune;

public interface X1StreamingOutputGenerator {

    String getString(final TrickPlayAndTune trickPlayAndTune);
}
