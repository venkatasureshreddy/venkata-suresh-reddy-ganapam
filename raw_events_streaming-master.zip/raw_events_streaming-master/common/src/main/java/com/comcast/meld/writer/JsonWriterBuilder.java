package com.comcast.meld.writer;

import gobblin.writer.DataWriter;
import gobblin.writer.SimpleDataWriterBuilder;

import java.io.IOException;

public class JsonWriterBuilder extends SimpleDataWriterBuilder {
    @Override
    public DataWriter<byte[]> build() throws IOException {
        return new JsonDataWriter(this, this.destination.getProperties());
    }
}
