package com.comcast.meld.partitioning;

public interface EventCategory {

    String MALFORMED_EVENT = "malformed_event";

    String INVALID_MESSAGE_TYPE = "invalid_message_type";

    String MALFORMED_EVENT_ALL = "malformed_event_all";

    String INVALID_MESSAGE_TYPE_ALL = "invalid_message_type_all";

    String INVALID_APP_NAME = "invalid_app_name";

    String getEventType();

    int checkLength();
}