package com.comcast.meld.writer;

import gobblin.configuration.State;
import gobblin.writer.DataWriter;
import gobblin.writer.SimpleDataWriterBuilder;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;

import java.io.IOException;

public class NativeStreamingWriterBuilder extends SimpleDataWriterBuilder {

   // GenericRecord partition;

    @Override
    public DataWriter<byte[]> build() throws IOException {
        return new NativeStreamingDataWriter(this, this.destination.getProperties());
    }

    //Overriding this method to avoid partitioning for pipe line delimiter output.
   /* @Override
    protected String getPartitionedFileName(State properties, String originalFileName) {

        return originalFileName;
    }

    @Override
    public boolean validatePartitionSchema(Schema partitionSchema) {
        return true;
    }*/
}
