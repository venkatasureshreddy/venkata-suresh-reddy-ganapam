package com.comcast.meld.generator;

import com.comcast.meld.schema.TrickPlayAndTune;
import com.google.common.collect.ImmutableMap;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class TrickPlayOutputGenerator implements X1StreamingOutputGenerator {
    private static final Logger LOG = Logger.getLogger(TrickPlayOutputGenerator.class);

    private static final ImmutableMap<String, String> rateMap;

    static {
        rateMap = ImmutableMap.<String, String>builder()
                .put("FWD_1", "0.5")
                .put("FWD_2", "15.0")
                .put("FWD_3", "30.0")
                .put("FWD_4", "60.0")
                .put("REW_1", "-0.5")
                .put("REW_2", "-15.0")
                .put("REW_3", "-30.0")
                .put("REW_4", "-60.0")
                .put("PLAY", "1.0")
                .put("PAUSE", "0.0")
                .put("LIVE", "1.0")
                .put("SKIP_REW", "1.0")
                .put("SKIP_FWD", "1.0")
                .put("FRAME_FWD", "0.5")
                .build();
    }

    public String getString(final TrickPlayAndTune trickPlayAndTune) {
        String tpName = trickPlayAndTune.getEvent().getEventValue().getTpName();
        String receiverId = trickPlayAndTune.getDev().getRecorderId();
        String controllerId = trickPlayAndTune.getHost();
        String timestampUtc = trickPlayAndTune.getEvent().getEts();
        String response = trickPlayAndTune.getEvent().getEventValue().getResponse();
        String rate = trickPlayAndTune.getEvent().getEventValue().getRate();
        String mode = trickPlayAndTune.getEvent().getEventValue().getMode();
        try {
            if (response.equalsIgnoreCase("n/a")) {
                if (StringUtils.isBlank(tpName) || tpName.equalsIgnoreCase("null")) {
                    rate = rateMap.get(rate);
                } else {
                    rate = rateMap.get(tpName);
                }
            } else {
                if (StringUtils.isBlank(rate)) {
                    rate = "0.0";
                }
            }
        } catch (NullPointerException e) {
            LOG.error("capture the invalid record causing by NULL pointerException***********"
                    + trickPlayAndTune.toString());
        } catch (Exception b) {
            LOG.error("capture the invalid record***********" + trickPlayAndTune.toString());
        }
        String zipCode = trickPlayAndTune.getLoc().getZip();
        String utcOffset = trickPlayAndTune.getLoc().getUtcOff();
        String offsetMilliSeconds = trickPlayAndTune.getEvent().getEventValue().getPosition();
        String offsetSeconds = "0.0";
        BigDecimal seconds = new BigDecimal("1000");
        //ONLY FOR DVR/VOD we have to get the offset else set to 0.0
        if (mode.equalsIgnoreCase("DVR") || mode.equalsIgnoreCase("VOD")) {
            if (offsetMilliSeconds == null || offsetMilliSeconds.equals("-1")
                    || offsetMilliSeconds.trim().isEmpty() || offsetMilliSeconds.equals("null")) {
                offsetSeconds = "0.0";
            } else {
                BigDecimal timeMilli = new BigDecimal(offsetMilliSeconds);
                offsetSeconds = String.valueOf(timeMilli.divide(seconds).setScale(2, RoundingMode.HALF_UP));
            }
        }
        String sourceReceivedTimestamp = trickPlayAndTune.getPoints();
        String meldReceivedTimestamp = String.valueOf(System.currentTimeMillis());

        return trickPlayAndTune.getEvent().getName() + "|" + receiverId + "|" + controllerId
                + "|" + timestampUtc + "|" + rate + "|" + offsetSeconds + "|" + zipCode + "|" + utcOffset
                + "|" + sourceReceivedTimestamp + "|" + meldReceivedTimestamp + "|" + "" + "|" + "" + "|" + "";

    }
}