package com.comcast.meld.partitioning;

import gobblin.configuration.State;
import gobblin.writer.partitioner.WriterPartitioner;
import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.log4j.Logger;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class NativeEventDayPartitioner implements WriterPartitioner<Object> {

    private static final String DATA_DIR = "data";
    private static final String DAY_ID = "eventdayidutc";
    private static final Pattern PIPE_DELIMITER_PATTERN = Pattern.compile("\\|");
    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    private static final Logger LOG = Logger.getLogger(NativeEventDayPartitioner.class);

    private static final Schema SCHEMA =
            SchemaBuilder
                    .record("Partitioning")
                    .namespace("gobblin.extract.kafka")
                    .fields()
                    .name(DATA_DIR)
                    .type(Schema.create(Schema.Type.STRING)).noDefault()
                    .name(DAY_ID)
                    .type(Schema.create(Schema.Type.STRING)).noDefault()
                    .endRecord();

    public NativeEventDayPartitioner() {
    }

    public NativeEventDayPartitioner(State state, int numBranches, int branchId) {
        this();
    }

    public Schema partitionSchema() {
        return SCHEMA;
    }

    @Override
    public GenericRecord partitionForRecord(Object messageBody) {
        GenericRecord partition = new GenericData.Record(SCHEMA);
        String dayId = null;
        try {
            String message = new String((byte[]) messageBody);
            String[] eventCategories = PIPE_DELIMITER_PATTERN.split(message);
            try {
                MainEventCategory mainEventCategory = MainEventCategory.valueOf(eventCategories[6]);
                EventCategory eventCategory = mainEventCategory.getEventCategory(eventCategories[7]);
                String eventDayIdUtc =
                        Optional
                                .ofNullable(eventCategory.checkLength())
                                .filter(input -> eventCategories.length == input)
                                .map(integer -> getEventDayId(eventCategories))
                                .orElse(EventCategory.MALFORMED_EVENT_ALL);

                dayId = appendDayID(eventDayIdUtc);
            } catch (final IllegalArgumentException | ArrayIndexOutOfBoundsException e) {
                String eventDayId = getEventDayId(eventCategories);
                dayId = appendDayID(eventDayId);
            }
        } catch (PatternSyntaxException | ClassCastException e) {
            dayId = EventCategory.MALFORMED_EVENT_ALL;
            LOG.error(e.getMessage(), e);
        } finally {
            partition.put(DAY_ID, dayId);
            partition.put(DATA_DIR, DATA_DIR);
        }
        LOG.debug("DATA_DIR = " + partition.get(DATA_DIR));
        LOG.info("DAY_ID = " + partition.get(DAY_ID));
        return partition;
    }

    public String getEventDayId(final String[] eventCategories) {
        try {
            final LocalDate localDate = LocalDate.parse(eventCategories[0], dateTimeFormatter);
            final Long tupleUnixTime = getEpochSecond(localDate);
            final Long systemUnixTime = getEpochSecond(LocalDate.now());

            if (tupleUnixTime <= systemUnixTime) {
                return localDate.toString();
            } else {
                return "future_event";
            }
        } catch (final RuntimeException e) {
            return EventCategory.MALFORMED_EVENT_ALL;
        }
    }

    private static Long getEpochSecond(final LocalDate localDate) {
        return localDate.atStartOfDay(ZoneOffset.UTC).toEpochSecond();
    }

    private static String appendDayID(final String dayID) {
        return "day_id=".concat(dayID);
    }
}
