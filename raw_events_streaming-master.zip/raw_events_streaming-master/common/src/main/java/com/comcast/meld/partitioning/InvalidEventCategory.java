package com.comcast.meld.partitioning;

public class InvalidEventCategory implements EventCategory {
    @Override
    public String getEventType() {
        return "invalid_message_type";
    }

    @Override
    public int checkLength() {
        return 0;
    }
}
