package com.comcast.meld.partitioning;

import gobblin.configuration.State;
import gobblin.writer.partitioner.WriterPartitioner;

import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.text.DateFormat;   
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
* This process iterates for every record in the kafka topic takes event name
* and event time stamp from the record to generate corresponding day_id
* partition
*
* @author rjetti200
*/

@SuppressWarnings("rawtypes")
public class VoiceRemoteStreamingEventPartitioner implements WriterPartitioner {

    private static final String CONFIG_FILE_NAME = "gobblin_kafka_pull.properties";
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    private static final Logger LOG = Logger.getLogger(X1StreamingEventPartitioner.class);
    private static final String DATA_DIR = "data";
    private static final String DAY_ID = "day_id";
    private static final String EVENT_NAME = "event_name";
    private static final String MALFORMED_EVENT = "malformed_event";
    private Properties pullConfig = null;
   /* private final String timeStampPrefixDelim;
    private final String timeStampSuffixDelim; */
    private final Pattern timeStampPattern;

    private static final Schema SCHEMA = SchemaBuilder.record("Partitioning").namespace("gobblin.extract.kafka")
            .fields().name(DATA_DIR)
            .type(Schema.create(Schema.Type.STRING)).noDefault().name(DAY_ID)
            .type(Schema.create(Schema.Type.STRING)).noDefault()
            .endRecord();

    public VoiceRemoteStreamingEventPartitioner() {

        DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("Etc/UTC"));

        // assigning the properties file from which the properties should be
        // pulled
        pullConfig = new Properties();
        try {
            pullConfig.load(ClassLoader.getSystemResourceAsStream(CONFIG_FILE_NAME));
        } catch (IOException e) {
            LOG.error("Encountered error while reading configuration properties: " + e.getMessage());
            LOG.error(e.getLocalizedMessage(), e);
        }

        timeStampPattern = Pattern.compile("\"startTs\":" + "(.*?)" + ",");
        
    }

    public VoiceRemoteStreamingEventPartitioner (State state, int numBranches, int branchId) {
        this();
    }

    @Override
    // generate a record with event name and the day_id
    public GenericRecord partitionForRecord(Object message) {

        GenericRecord partition = new GenericData.Record(SCHEMA);
        String eventTimestampUTC = null;
        String eventDayIdUtc = null;
        Matcher matcher = null;
        String body = null;

        try {
            body = new String((byte[]) message);
        } catch (ClassCastException e) {
            e.printStackTrace();
            partition.put(EVENT_NAME, "invalid_event");
            partition.put(DAY_ID, "day_id=" + MALFORMED_EVENT);
            return partition;

        }

        try {
            matcher = timeStampPattern.matcher(body);
            matcher.find();
            eventTimestampUTC = matcher.group(1).trim();

        LOG.info("Starts ********* " + eventTimestampUTC);

        } catch (IllegalStateException | IndexOutOfBoundsException e) {
            LOG.warn("Event timestamp column has NULL value and process this event as malformed_event -- " + body);
            eventDayIdUtc = MALFORMED_EVENT;
            LOG.error(e.getLocalizedMessage(), e);
        }

        // Validate the time stamp
        if (eventTimestampUTC == null || eventTimestampUTC.length() != 13) {
            eventDayIdUtc = MALFORMED_EVENT;
        } else {
            try {
                eventDayIdUtc = getEventDayId(eventTimestampUTC);
            } catch (ParseException e) {
                LOG.error("dfm parse exception for eventTimestampUTC " + e.getMessage());
                eventDayIdUtc = MALFORMED_EVENT;
                LOG.error(e.getLocalizedMessage(), e);
            }
        }

        partition.put(DATA_DIR, DATA_DIR);
        partition.put(DAY_ID, "day_id=" + eventDayIdUtc);
        return partition;

    }

    @Override
    public Schema partitionSchema() {
        return SCHEMA;
    }
    		
    // getting day_id for the corresponding timeStamp
    public static String getEventDayId(String timestampUtc) throws ParseException {
       long tupleUnixtime = 0L;
       long SystemUnixtime = 0L;
        try {
            tupleUnixtime = Long.parseLong(timestampUtc.substring(0, 10));
        } catch (NumberFormatException e) {
            LOG.error("timestamp is invalid and process this event as malformed_event -- " + timestampUtc);
            LOG.error(e.getLocalizedMessage(), e);
            return MALFORMED_EVENT;
        }

      /* SystemUnixtime = (System.currentTimeMillis() / 1000) + 86400; */
        
	Date today = new Date(); // Start date
	
	Calendar c = Calendar.getInstance();
	c.setTime(today);
	c.add(Calendar.DATE, 1);  
	System.out.println(c.getTimeInMillis()/1000);
	String longstr = c.getTimeInMillis()/1000+"";
	
	SystemUnixtime = Long.parseLong(longstr);
	
        		
        if (tupleUnixtime > SystemUnixtime) {
            return "future_event";
        } else {
            long epochTime = 0L;
            Date date = null;
            try {
                epochTime = Long.parseLong(timestampUtc);
            } catch (NumberFormatException e) {
                LOG.error("timestamp is invalid and process this event as malformed_event -- " + timestampUtc);
                LOG.error(e.getLocalizedMessage(), e);
                return MALFORMED_EVENT;
            }

            date = new Date(epochTime);
            String result = null;
            synchronized (X1StreamingEventPartitioner.class) {
                result = DATE_FORMAT.format(date);
            }
            return result;
        }
    }
}