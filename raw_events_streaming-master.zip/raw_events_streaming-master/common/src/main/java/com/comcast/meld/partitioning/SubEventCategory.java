package com.comcast.meld.partitioning;

import java.util.Arrays;
import java.util.function.Predicate;

public enum SubEventCategory implements EventCategory {
    XO(17, MainEventCategory.X, "status_option", "O"),
    XL(18, MainEventCategory.X, "status_lock", "L"),
    XS(16, MainEventCategory.X, "status_current_state", "S"),
    XC(19, MainEventCategory.X, "status_current_channel", "C"),
    XM(19, MainEventCategory.X, "status_dvr_recording", "M"),
    HL(17, MainEventCategory.H, "highlight_nongrid_list", "L"),
    HB(17, MainEventCategory.H, "highlight_browse_screen", "B"),
    HM(17, MainEventCategory.H, "highlight_menu_screen", "M"),
    HQ(17, MainEventCategory.H, "highlight_quick_access_screen", "Q"),
    HA(17, MainEventCategory.H, "highlight_action_icon", "A"),
    HO(17, MainEventCategory.H, "highlight_overlay", "O"),
    HG(17, MainEventCategory.H, "highlight_grid_list", "G"),
    HS(17, MainEventCategory.H, "highlight_setup_option", "S"),
    HK(17, MainEventCategory.H, "highlight_keyboard_option", "K"),
    HD(17, MainEventCategory.H, "highlight_advertisement", "D"),
    HV(17, MainEventCategory.H, "highlight_video_rich_nvgt_scrn", "V");

    private final int checkLength;
    private final MainEventCategory parent;
    private final String eventType;
    private final String eventCategory;

    SubEventCategory(
            final int checkLength,
            final MainEventCategory parent,
            final String eventType,
            final String eventCategory) {

        this.checkLength = checkLength;
        this.parent = parent;
        this.eventType = eventType;
        this.eventCategory = eventCategory;
    }


    @Override
    public String getEventType() {
        return eventType;
    }

    @Override
    public int checkLength() {
        return checkLength;
    }

    public static EventCategory getChildEventCategory(
            final MainEventCategory theParentEventCategory,
            final String theEventCategory) {

        final Predicate<SubEventCategory> subEventCategoryPredicate =
                subEventCategory -> subEventCategory.parent == theParentEventCategory &&
                        subEventCategory.eventCategory.equals(theEventCategory);

        return Arrays
                .asList(values())
                .stream()
                .filter(subEventCategoryPredicate)
                .findAny()
                .map(subEventCategory -> (EventCategory) subEventCategory)
                .orElse(new InvalidEventCategory());
    }
}