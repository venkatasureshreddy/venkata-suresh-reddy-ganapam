package com.comcast.meld.generator;

import com.comcast.meld.schema.TrickPlayAndTune;
import org.apache.log4j.Logger;

public class TuneOutputGenerator implements X1StreamingOutputGenerator {
    private static final Logger LOG = Logger.getLogger(TrickPlayOutputGenerator.class);

    public String getString(final TrickPlayAndTune trickPlayAndTune) {

        String receiverId = trickPlayAndTune.getDev().getRecorderId();
        String controllerId = trickPlayAndTune.getHost();
        String timestampUtc = trickPlayAndTune.getEvent().getEts();
        String isStartup = trickPlayAndTune.getEvent().getEventValue().getStartUP();
        String url = trickPlayAndTune.getEvent().getEventValue().getLocator();
        String sourceId = "";
        try {
            sourceId = trickPlayAndTune.getEvent().getEventValue().getCid();
        } catch (Exception e) {
            LOG.info("Input wrong tune JSON Event  " + trickPlayAndTune.toString());
        }
        String pid = trickPlayAndTune.getEvent().getEventValue().getPid();
        String zipCode = trickPlayAndTune.getLoc().getZip();
        String utcOffset = trickPlayAndTune.getLoc().getUtcOff();
        String sourceReceivedTimestamp = trickPlayAndTune.getPoints();
        String meldReceivedTimestamp = "";
        String tuningStartTs = "";

        return trickPlayAndTune.getEvent().getName() + "|" + receiverId + "|" + controllerId
                + "|" + timestampUtc + "|" + url + "|" + sourceId + "|"
                + pid + "|" + zipCode + "|" + utcOffset + "|" + isStartup + "|" + sourceReceivedTimestamp
                + "|" + meldReceivedTimestamp + "|" + tuningStartTs + "|" + "" + "|" + "" ;

    }
}
