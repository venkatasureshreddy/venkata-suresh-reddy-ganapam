package com.comcast.meld.schema;

import com.comcast.meld.schema.*;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TrickPlayAndTune {
    @JsonProperty("PV")
    private String pv;
    @JsonProperty("APP")
    private APP app;
    @JsonProperty("DEV")
    private DEV dev;
    @JsonProperty("ACNT")
    private Account account;
    @JsonProperty("LOC")
    private LOC loc;
    @JsonProperty("EVT")
    private Event event;
    @JsonProperty("HOST")
    private String host;
    @JsonProperty("PTS")
    private String points;
    

    public TrickPlayAndTune() {

    }

    public String getPv() {
        return pv;
    }

    public void setPv(String pv) {
        this.pv = pv;
    }

    public APP getApp() {
        return app;
    }

    public void setApp(APP app) {
        this.app = app;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }

    
    public String getEventStatus() {
        return event.getEventValue().getStatus();
    }
    
    public DEV getDev() {
        return dev;
    }

    public void setDev(DEV dev) {
        this.dev = dev;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public LOC getLoc() {
        return loc;
    }

    public void setLoc(LOC loc) {
        this.loc = loc;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getPoints() {
        return points;
    }

    public void setPoints(String points) {
        this.points = points;
    }

}
