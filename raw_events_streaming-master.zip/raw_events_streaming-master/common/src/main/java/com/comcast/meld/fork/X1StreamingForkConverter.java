package com.comcast.meld.fork;

import gobblin.configuration.WorkUnitState;
import gobblin.converter.Converter;
import gobblin.converter.DataConversionException;
import gobblin.converter.SchemaConversionException;
import gobblin.converter.SingleRecordIterable;

public class X1StreamingForkConverter extends Converter<String, CopyableSchema, byte[], CopyableRecord> {

    @Override
    public CopyableSchema convertSchema(String inputSchema, WorkUnitState workUnit) throws SchemaConversionException {

        return new CopyableSchema(inputSchema);
    }

    @Override
    public Iterable<CopyableRecord> convertRecord(CopyableSchema outputSchema, byte[] inputRecord, WorkUnitState workUnit) throws DataConversionException {

        return new SingleRecordIterable<>(new CopyableRecord(inputRecord));
    }
}
