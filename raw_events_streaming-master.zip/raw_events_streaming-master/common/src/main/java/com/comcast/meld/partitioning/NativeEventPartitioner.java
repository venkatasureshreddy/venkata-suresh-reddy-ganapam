package com.comcast.meld.partitioning;

import gobblin.configuration.State;
import gobblin.writer.partitioner.WriterPartitioner;
import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class NativeEventPartitioner implements WriterPartitioner<Object> {

    private static final String EVENT_NAME = "eventtype";
    private static final String DATA_DIR = "data";
    private static final String DAY_ID = "eventdayidutc";
    private static final Pattern PIPE_DELIMITER_PATTERN = Pattern.compile("\\|");
    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    private static final Schema SCHEMA =
            SchemaBuilder
                    .record("Partitioning")
                    .namespace("gobblin.extract.kafka")
                    .fields()
                    .name(EVENT_NAME)
                    .type(Schema.create(Schema.Type.STRING)).noDefault()
                    .name(DATA_DIR)
                    .type(Schema.create(Schema.Type.STRING)).noDefault()
                    .name(DAY_ID)
                    .type(Schema.create(Schema.Type.STRING)).noDefault()
                    .endRecord();

    public NativeEventPartitioner() {
    }

    public NativeEventPartitioner(State state, int numBranches, int branchId) {
        this();
    }

    public Schema partitionSchema() {
        return SCHEMA;
    }

    @Override
    public GenericRecord partitionForRecord(final Object messageBody) {
        final GenericRecord partition = new GenericData.Record(SCHEMA);
        try {
            final String message = new String((byte[]) messageBody);
            final String[] eventCategories = PIPE_DELIMITER_PATTERN.split(message);
            try {
                final MainEventCategory mainEventCategory = MainEventCategory.valueOf(eventCategories[6]);
                final EventCategory eventCategory = mainEventCategory.getEventCategory(eventCategories[7]);

                final String eventType = eventCategory.getEventType();
                final String eventDayIdUtc =
                        Optional
                                .ofNullable(eventCategory.checkLength())
                                .filter(input -> eventCategories.length == input)
                                .map(integer -> getEventDayId(eventCategories))
                                .orElse(EventCategory.MALFORMED_EVENT);

                partition.put(EVENT_NAME, eventType);
                partition.put(DAY_ID, appendDayID(eventDayIdUtc));
            } catch (final IllegalArgumentException | ArrayIndexOutOfBoundsException e) {
                partition.put(EVENT_NAME, EventCategory.INVALID_MESSAGE_TYPE);
                final String eventDayId = getEventDayId(eventCategories);
                partition.put(DAY_ID, appendDayID(eventDayId));
            }
        } catch (final PatternSyntaxException | ClassCastException e) {
            partition.put(EVENT_NAME, EventCategory.INVALID_MESSAGE_TYPE);
            partition.put(DAY_ID, EventCategory.MALFORMED_EVENT);
        }
        partition.put(DATA_DIR, DATA_DIR);
        return partition;
    }

    public String getEventDayId(final String[] eventCategories) {
        try {
            final LocalDate localDate = LocalDate.parse(eventCategories[0], dateTimeFormatter);
            final Long tupleUnixTime = getEpochSecond(localDate);
            final Long systemUnixTime = getEpochSecond(LocalDate.now());

            if (tupleUnixTime <= systemUnixTime) {
                return localDate.toString();
            } else {
                return "future_event";
            }
        } catch (final RuntimeException e) {
            return EventCategory.MALFORMED_EVENT;
        }
    }

    private static Long getEpochSecond(final LocalDate localDate) {
        return localDate.atStartOfDay(ZoneOffset.UTC).toEpochSecond();
    }

    private static String appendDayID(final String dayID) {
        return "day_id=".concat(dayID);
    }
}
