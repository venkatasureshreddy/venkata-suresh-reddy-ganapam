package com.comcast.meld.writer;

import com.google.common.base.Preconditions;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import gobblin.configuration.State;
import gobblin.writer.SimpleDataWriter;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonParseException;

import java.io.IOException;

public class JsonDataWriter extends SimpleDataWriter {
    private static final Logger LOG = Logger.getLogger(JsonDataWriter.class);

    public JsonDataWriter(final JsonWriterBuilder builder, final State properties) throws IOException {
        super(builder, properties);
    }

    /**
     * Write a source record to the staging file
     *
     * @param genericRecord data record to write
     * @throws IOException if there is anything wrong writing the record
     */
   @Override
   public void write(final byte[] genericRecord) throws IOException {
        try {
            Preconditions.checkNotNull(genericRecord);
            final Gson gson = new Gson();
            final JsonObject jsonObject = gson.fromJson(new String(genericRecord), JsonObject.class);
            final JsonObject event=(JsonObject)jsonObject.get("EVT");
            final JsonObject eventValue=((JsonObject) event.get("VALUE"));
            if ( event.get("NAME").toString().equals("\"tune\"") && eventValue.get("STATUS").toString().equalsIgnoreCase("\"FAILURE\""))
            {
            	// skipping the tune failure records
            }
            else
            {
            jsonObject.addProperty("MELD_RTS", System.currentTimeMillis());
            super.write(jsonObject.toString().getBytes());
            }
        } catch (RuntimeException | JsonParseException e) {
            LOG.error(e.getMessage());
        }
    }
}