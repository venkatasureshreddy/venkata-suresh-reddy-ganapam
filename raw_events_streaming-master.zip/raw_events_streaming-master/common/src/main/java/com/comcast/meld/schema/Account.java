package com.comcast.meld.schema;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties("ACNT")
public class Account {
    @JsonProperty("BILL_ID")
    private String billID;
    @JsonProperty("ACCOUNT_SOURCE_ID")
    private String sourceID;
    @JsonProperty("PARTNER")
    private String partner;
    @JsonProperty("XBO_ID")
    private String xboID;

    public Account() {

    }

    public String getBillID() {
        return billID;
    }

    public void setBillID(String billID) {
        this.billID = billID;
    }

    public String getSourceID() {
        return sourceID;
    }

    public void setSourceID(String sourceID) {
        this.sourceID = sourceID;
    }

    public String getPartner() {
        return partner;
    }

    public void setPartner(String partner) {
        this.partner = partner;
    }

    public String getXboID() {
        return xboID;
    }

    public void setXboID(String xboID) {
        this.xboID = xboID;
    }
}
