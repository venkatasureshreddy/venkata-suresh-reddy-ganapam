package com.comcast.meld.schema;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DEV {
    @JsonProperty("REC_ID")
    private String recorderId;
    @JsonProperty("ECM_MAC")
    private String ecmMac;
    @JsonProperty("ESTB_MAC")
    private String estbMac;
    @JsonProperty("DEVICE_TYPE")
    private String deviceType;
    @JsonProperty("DEVICE_SOURCE_ID")
    private String deviceSourceId;
    @JsonProperty("PHYSICAL_DEVICE_ID")
    private String physicalDeviceId;
    @JsonProperty("FIRMWARE_VERSION")
    private String firmwareVersion;

    public DEV() {

    }

    public String getRecorderId() {
        return recorderId;
    }

    public void setRecorderId(String recorderId) {
        this.recorderId = recorderId;
    }

    public String getEcmMac() {
        return ecmMac;
    }

    public void setEcmMac(String ecmMac) {
        this.ecmMac = ecmMac;
    }

    public String getEstbMac() {
        return estbMac;
    }

    public void setEstbMac(String estbMac) {
        this.estbMac = estbMac;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceSourceId() {
        return deviceSourceId;
    }

    public void setDeviceSourceId(String deviceSourceId) {
        this.deviceSourceId = deviceSourceId;
    }

    public String getPhysicalDeviceId() {
        return physicalDeviceId;
    }

    public void setPhysicalDeviceId(String physicalDeviceId) {
        this.physicalDeviceId = physicalDeviceId;
    }

    public String getFirmwareVersion() {
        return firmwareVersion;
    }

    public void setFirmwareVersion(String firmwareVersion) {
        this.firmwareVersion = firmwareVersion;
    }
}
