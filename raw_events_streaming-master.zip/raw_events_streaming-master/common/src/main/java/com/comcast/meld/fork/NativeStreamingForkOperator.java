package com.comcast.meld.fork;

import com.google.common.collect.ImmutableList;
import gobblin.configuration.WorkUnitState;
import gobblin.fork.ForkOperator;


import java.io.IOException;
import java.util.List;

public class NativeStreamingForkOperator implements ForkOperator<CopyableSchema, CopyableRecord> {
    @Override
    public void init(WorkUnitState workUnitState) throws Exception {
    }

    @Override
    public int getBranches(WorkUnitState workUnitState) {
        return 2;
    }

    @Override
    public List<Boolean> forkSchema(WorkUnitState workUnitState, CopyableSchema input) {
        return ImmutableList.of(Boolean.TRUE, Boolean.TRUE);
    }

    @Override
    public List<Boolean> forkDataRecord(WorkUnitState workUnitState, CopyableRecord input) {
        return ImmutableList.of(Boolean.TRUE, Boolean.TRUE);
    }

    @Override
    public void close() throws IOException {

    }
}
