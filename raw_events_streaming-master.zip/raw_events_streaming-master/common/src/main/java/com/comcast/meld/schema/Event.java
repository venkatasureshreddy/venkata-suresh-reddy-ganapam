package com.comcast.meld.schema;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Event {
    @JsonProperty("ETS")
    private String ets;
    @JsonProperty("NAME")
    private String name;
    @JsonProperty("RTS")
    private String rts;
    @JsonProperty("VALUE")
    private EventValue eventValue;

    public Event() {

    }

    public String getEts() {
        return ets;
    }

    public void setEts(String ets) {
        this.ets = ets;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRts() {
        return rts;
    }

    public void setRts(String rts) {
        this.rts = rts;
    }

    public EventValue getEventValue() {
        return eventValue;
    }

    public void setEventValue(EventValue eventValue) {
        this.eventValue = eventValue;
    }


}
