package com.comcast.meld.schema;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LOC {
    @JsonProperty("REGION")
    private String region;
    @JsonProperty("MARKET")
    private String market;
    @JsonProperty("DMA")
    private String dma;
    @JsonProperty("ZIP")
    private String zip;
    @JsonProperty("LAT")
    private String lat;
    @JsonProperty("LONG")
    private String longLoc;
    @JsonProperty("UTC_OFF")
    private String utcOff;

    public LOC() {

    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getMarket() {
        return market;
    }

    public void setMarket(String market) {
        this.market = market;
    }

    public String getDma() {
        return dma;
    }

    public void setDma(String dma) {
        this.dma = dma;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLongLoc() {
        return longLoc;
    }

    public void setLongLoc(String longLoc) {
        this.longLoc = longLoc;
    }

    public String getUtcOff() {
        return utcOff;
    }

    public void setUtcOff(String utcOff) {
        this.utcOff = utcOff;
    }
}
