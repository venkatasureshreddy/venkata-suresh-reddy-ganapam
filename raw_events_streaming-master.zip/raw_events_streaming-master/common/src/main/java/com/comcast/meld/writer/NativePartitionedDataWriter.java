package com.comcast.meld.writer;

import com.google.common.base.Preconditions;
import gobblin.configuration.State;
import gobblin.writer.SimpleDataWriter;
import org.apache.log4j.Logger;

import java.io.IOException;

public class NativePartitionedDataWriter extends SimpleDataWriter {
    private static final Logger LOG = Logger.getLogger(NativePartitionedDataWriter.class);

    public NativePartitionedDataWriter(final NativePartitionedWriterBuilder builder, final State properties) throws IOException {
        super(builder, properties);
    }

    /**
     * Write a source record to the staging file
     *
     * @param genericRecord data record to write
     * @throws IOException if there is anything wrong writing the record
     */
   @Override
   public void write(final byte[] genericRecord) throws IOException {
        try {
           // Preconditions.checkNotNull(genericRecord);
           
            super.write(genericRecord);
            
        } catch (RuntimeException e) {
            LOG.error(e.getMessage());
        }
    }
}