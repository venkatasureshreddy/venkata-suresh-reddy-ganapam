package com.comcast.meld.schema;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EventValue {
    @JsonProperty("RESPONSE")
    private String response;
    @JsonProperty("RATE")
    private String rate;
    @JsonProperty("TPNAME")
    private String tpName;
    @JsonProperty("MODE")
    private String mode;
    @JsonProperty("POSITION")
    private String position;
    @JsonProperty("RTS")
    private String rts;
    @JsonProperty("TYPE")
    private String type;
    @JsonProperty("STATUS")
    private String status;
    @JsonProperty("STATUS_MESSAGE")
    private String statusMessage;
    @JsonProperty("PID")
    private String pid;
    @JsonProperty("RPID")
    private String rpID;
    @JsonProperty("CID")
    private String cid;
    @JsonProperty("LID")
    private String lid;
    @JsonProperty("SID")
    private String sid;
    @JsonProperty("RPIL_SID")
    private String rpilSID;
    @JsonProperty("TITLE")
    private String title;
    @JsonProperty("LOCATOR")
    private String locator;
    @JsonProperty("COMPANY_NAME")
    private String companyName;
    @JsonProperty("NOTIFY_TYPE")
    private String notifyType;
    @JsonProperty("LATENCY")
    private String latency;
    @JsonProperty("IS_STARTUP")
    private String startUP;
    @JsonProperty("MEDIA_GUID")
    private String mediaGUID;
    @JsonProperty("DELIVERY_MEDIUM")
    private String deliveryMedium;
    @JsonProperty("IS_RESTORED")
    private String restored;

    public EventValue() {

    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getTpName() {
        return tpName;
    }

    public void setTpName(String tpName) {
        this.tpName = tpName;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getRts() {
        return rts;
    }

    public void setRts(String rts) {
        this.rts = rts;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getRpID() {
        return rpID;
    }

    public void setRpID(String rpID) {
        this.rpID = rpID;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getLid() {
        return lid;
    }

    public void setLid(String lid) {
        this.lid = lid;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getRpilSID() {
        return rpilSID;
    }

    public void setRpilSID(String rpilSID) {
        this.rpilSID = rpilSID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLocator() {
        return locator;
    }

    public void setLocator(String locator) {
        this.locator = locator;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getNotifyType() {
        return notifyType;
    }

    public void setNotifyType(String notifyType) {
        this.notifyType = notifyType;
    }

    public String getLatency() {
        return latency;
    }

    public void setLatency(String latency) {
        this.latency = latency;
    }

    public String getStartUP() {
        return startUP;
    }

    public void setStartUP(String startUP) {
        this.startUP = startUP;
    }

    public String getMediaGUID() {
        return mediaGUID;
    }

    public void setMediaGUID(String mediaGUID) {
        this.mediaGUID = mediaGUID;
    }

    public String getDeliveryMedium() {
        return deliveryMedium;
    }

    public void setDeliveryMedium(String deliveryMedium) {
        this.deliveryMedium = deliveryMedium;
    }

    public String getRestored() {
        return restored;
    }

    public void setRestored(String restored) {
        this.restored = restored;
    }
}
