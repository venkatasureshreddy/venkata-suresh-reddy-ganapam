package com.comcast.meld.fork;

import gobblin.fork.CopyNotSupportedException;
import gobblin.fork.Copyable;

public class CopyableRecord implements Copyable<byte[]> {
    private final byte[] record;

    public CopyableRecord(byte[] record) {
        this.record = record;
    }

    @Override
    public byte[] copy() throws CopyNotSupportedException {
        if (!(this.record instanceof byte[])) {
            throw new CopyNotSupportedException(
                    "The record to make copy is not an instance of " + byte[].class.getName());
        }
        // Make a deep copy of the original record
        return new String(record).getBytes();
    }
}
