package com.comcast.meld.partitioning;

import gobblin.configuration.State;
import gobblin.writer.partitioner.WriterPartitioner;
import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DigitalHttpEventPartitioner implements WriterPartitioner<GenericRecord> {

    private static final Logger LOG = LoggerFactory.getLogger(DigitalHttpEventPartitioner.class);

    private static final String APP_NAME = "app_name";
    private static final String DATA_DIR = "data";
    private static final String DAY_ID = "day_id";

    private static final DateTimeFormatter DAY_ID_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private static final String TIME_MALFORMED_EVENT = "malformed_timestamp";
    private static final String APP_MALFORMED_EVENT = "malformed_appname";
    private static final String FUTURE_EVENT = "future_event";

    private static final Pattern TIME_STAMP_PATTERN = Pattern.compile("\"timestamp\":" + "[ ]*?(.*?)" + ",");
    private static final Pattern APP_NAME_PATTERN = Pattern.compile("\"APP_NAME\":[ ]*?\"([^,}]*?)\",");

    private static final Schema SCHEMA =
            SchemaBuilder
                    .record("Partitioning")
                    .namespace("gobblin.extract.kafka")
                    .fields()
                    .name(DATA_DIR)
                    .type(Schema.create(Schema.Type.STRING)).noDefault()
                    .name(DAY_ID)
                    .type(Schema.create(Schema.Type.STRING)).noDefault()
                    .name(APP_NAME)
                    .type(Schema.create(Schema.Type.STRING)).noDefault()
                    .endRecord();

    public DigitalHttpEventPartitioner() {
    }

    public DigitalHttpEventPartitioner(final State state, final int numBranches, final int branchId) {
        this();
    }

    @Override
    public Schema partitionSchema() {
        return SCHEMA;
    }

    @Override
    public GenericRecord partitionForRecord(final GenericRecord record) {

        final GenericRecord partition = new GenericData.Record(SCHEMA);

        try {

            final Matcher appNameMatcher = APP_NAME_PATTERN.matcher(record.toString());
            appNameMatcher.find();

            final String appName = Optional
                    .of(appNameMatcher.group(1).trim())
                    .orElse(APP_MALFORMED_EVENT);

            final Matcher dayIDMatcher = TIME_STAMP_PATTERN.matcher(record.toString());
            dayIDMatcher.find();

            final String eventDayId = Optional
                    .of(dayIDMatcher.group(1).trim())
                    .orElse(TIME_MALFORMED_EVENT);

            partition.put(APP_NAME, appendAppName(appName));
            partition.put(DAY_ID, appendDayID(getEventDayId(eventDayId)));

        } catch (final RuntimeException e) {
            partition.put(APP_NAME, appendAppName(APP_MALFORMED_EVENT));
            partition.put(DAY_ID, appendDayID(TIME_MALFORMED_EVENT));
            LOG.error("ERROR OCCURRED IN MAIN BLOCK :: {}", e.getMessage());
        }

        partition.put(DATA_DIR, "data");

        return partition;
    }

    public static String getEventDayId(final String epochTimeStr) {
        try {

            final Long epochTime = Long.valueOf(epochTimeStr);

            final LocalDate dayIDDate =
                    LocalDateTime.ofInstant(Instant.ofEpochMilli(epochTime), ZoneId.systemDefault()).toLocalDate();
            final LocalDate now = LocalDate.now();
            if (!dayIDDate.isAfter(now)) {
                return DAY_ID_FORMAT.format(dayIDDate);
            }

            return FUTURE_EVENT;

        } catch (final RuntimeException e) {
            LOG.error("Error While Getting Event Day ID :: {}", e.getMessage());
        }

        return TIME_MALFORMED_EVENT;
    }

    private static String appendDayID(final String dayID) {
        return "day_id=".concat(dayID);
    }

    private static String appendAppName(final String appName) {
        return "app_name=".concat(appName);
    }

}
