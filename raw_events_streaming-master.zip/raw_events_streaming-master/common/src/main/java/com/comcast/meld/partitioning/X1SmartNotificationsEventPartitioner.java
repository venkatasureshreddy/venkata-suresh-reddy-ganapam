package com.comcast.meld.partitioning;

import gobblin.configuration.State;
import gobblin.writer.partitioner.WriterPartitioner;
import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * This process iterates for every record in the kafka topic takes event feature group, event type
 * and event time stamp from the record to generate corresponding day_id
 * partition
 *
 * @author Rajesh Jetti
 */

@SuppressWarnings("rawtypes")
public class X1SmartNotificationsEventPartitioner implements WriterPartitioner {

    private static final String CONFIG_FILE_NAME = "gobblin_kafka_pull.properties";
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    private static final Logger LOG = Logger.getLogger(X1SmartNotificationsEventPartitioner.class);
    private static final String DATA_DIR = "data";
    private static final String DAY_ID = "day_id";
    private static final String EVENT_NAME = "event_name";
    private static final String MALFORMED_EVENT = "malformed_event";
    private Properties pullConfig = null;
    private final Pattern feature; 

    private static final Schema SCHEMA = SchemaBuilder.record("Partitioning").namespace("gobblin.extract.kafka")
            .fields().name(DATA_DIR)
            .type(Schema.create(Schema.Type.STRING)).noDefault().name(DAY_ID)
            .type(Schema.create(Schema.Type.STRING)).noDefault()
            .endRecord();

    public X1SmartNotificationsEventPartitioner() {

        DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("Etc/UTC"));

        // assigning the properties file from which the properties should be
        // pulled
        pullConfig = new Properties();
        try {
            pullConfig.load(ClassLoader.getSystemResourceAsStream(CONFIG_FILE_NAME));
        } catch (IOException e) {
            LOG.error("Encountered error while reading configuration properties: " + e.getMessage());
            LOG.error(e.getLocalizedMessage(), e);
        }
        
        feature = Pattern.compile("\\{(\\SfeatureGroup\":\"Notifications\")");
        
    }

    public X1SmartNotificationsEventPartitioner(State state, int numBranches, int branchId) {
        this();
    }

    @Override
    // generate a record with based on feature group, event and the day_id
    public GenericRecord partitionForRecord(Object message) {

        GenericRecord partition = new GenericData.Record(SCHEMA);
        String featureGroup= null; 
        String eventTimestampUTC = null;
        String eventDayIdUtc = null;
        Matcher matcher = null;
        String body = null;
        Date date = null;

        try {
            body = new String((byte[]) message);
            String dayId[] = body.split(" ", 2); 
            eventTimestampUTC = dayId[0];
        } catch (ClassCastException | ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
            partition.put(EVENT_NAME, "invalid_event");
            partition.put(DAY_ID, "day_id=" + MALFORMED_EVENT);
            return partition;
        }
        
        try {
            matcher = feature.matcher(body);
            matcher.find();
            featureGroup = matcher.group(0).trim();
        } catch (IllegalStateException | IndexOutOfBoundsException e) {
            LOG.warn("Event timestamp column has NULL value and process this event as malformed_event -- " + body);
            eventDayIdUtc = MALFORMED_EVENT;
            LOG.error(e.getLocalizedMessage(), e);
        }
        
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            dateFormat.setLenient(false);
            date = dateFormat.parse(eventTimestampUTC);
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        if (featureGroup == null || eventTimestampUTC.length() != 10 || date == null) {
            eventDayIdUtc = MALFORMED_EVENT;
        } else {
            eventDayIdUtc = eventTimestampUTC;
        }   
        
        partition.put(DATA_DIR, DATA_DIR);
        partition.put(DAY_ID, "day_id=" + eventDayIdUtc);
        return partition;          
    }

    @Override
    public Schema partitionSchema() {
        return SCHEMA;
    } 
}

