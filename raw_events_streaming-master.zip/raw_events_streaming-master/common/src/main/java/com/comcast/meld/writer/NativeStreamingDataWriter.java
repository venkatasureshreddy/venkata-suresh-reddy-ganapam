package com.comcast.meld.writer;

import com.comcast.meld.partitioning.EventCategory;
import com.comcast.meld.partitioning.MainEventCategory;
import com.google.common.base.Preconditions;
import gobblin.configuration.State;
import gobblin.writer.SimpleDataWriter;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

public class NativeStreamingDataWriter extends SimpleDataWriter {
    private static Logger LOG = Logger.getLogger(NativeStreamingDataWriter.class);
    private static Pattern PIPE_DELIMITER_PATTERN = Pattern.compile("\\|");

    public NativeStreamingDataWriter(NativeStreamingWriterBuilder builder, State properties) throws IOException {
        super(builder, properties);
    }

    /**
     * Write a source record to the staging file
     *
     * @param genericRecord data record to write
     * @throws IOException if there is anything wrong writing the record
     */
    public void write(byte[] genericRecord) throws IOException {
        try {
            Preconditions.checkNotNull(genericRecord);
            boolean status = isSCREMPVEvent(genericRecord);
            if (status) {
                super.write(genericRecord);
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }
    }

    /**
     * Check the event type of native event.
     *
     * @param genericRecord - native event
     * @return - is record belongs to 7 event types
     */
    private boolean isSCREMPVEvent(byte[] genericRecord) throws Exception {
        boolean result = false;
        Set<String> setEventTypes = new HashSet<>();
        setEventTypes.add("S"); // state_change
        setEventTypes.add("C"); // channel_change_verbose
        setEventTypes.add("R"); // reset
        setEventTypes.add("E"); // program_event
        setEventTypes.add("M"); // missing_data
        setEventTypes.add("P"); // pulse
        setEventTypes.add("V"); // video_playback_session
        String message = new String(genericRecord);
        try {
            String[] eventCategories = PIPE_DELIMITER_PATTERN.split(message);
            MainEventCategory mainEventCategory = MainEventCategory.valueOf(eventCategories[6]);
            EventCategory eventCategory = mainEventCategory.getEventCategory(eventCategories[7]);
            String eventType = eventCategory.toString();
            if (setEventTypes.contains(eventType)) {
                result = true;
            }
            LOG.debug("success genericRecord=" + message);
        } catch (Exception e) {
            LOG.debug("error genericRecord=" + message);
            LOG.error(e.getMessage(), e);
            throw e;
        }
        return result;
    }
}
