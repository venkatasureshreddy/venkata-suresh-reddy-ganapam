package com.comcast.meld.source;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Optional;
import com.comcast.meld.extractor.HttpAvroExtractorCustom;

import gobblin.configuration.WorkUnitState;
import gobblin.metrics.kafka.KafkaAvroSchemaRegistry;
import gobblin.source.extractor.extract.kafka.KafkaSource;


/**
 * Created by bowenzheng on 8/22/17.
 */
public class KafkaAvroSource extends KafkaSource {

    private static final Logger LOG = LoggerFactory.getLogger(KafkaAvroSource.class);

    private Optional<KafkaAvroSchemaRegistry> schemaRegistry = Optional.absent();

    @Override
    public HttpAvroExtractorCustom getExtractor(WorkUnitState state) throws IOException {

        return new HttpAvroExtractorCustom(state);

    }


}
