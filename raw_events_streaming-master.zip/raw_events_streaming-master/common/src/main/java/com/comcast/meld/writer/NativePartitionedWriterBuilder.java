package com.comcast.meld.writer;

import gobblin.writer.DataWriter;
import gobblin.writer.SimpleDataWriterBuilder;

import java.io.IOException;

public class NativePartitionedWriterBuilder extends SimpleDataWriterBuilder {
    @Override
    public DataWriter<byte[]> build() throws IOException {
        return new NativePartitionedDataWriter(this, this.destination.getProperties());
    }
}
