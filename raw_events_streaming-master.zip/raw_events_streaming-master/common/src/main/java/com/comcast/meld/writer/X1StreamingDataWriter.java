package com.comcast.meld.writer;

import com.comcast.meld.generator.TrickPlayOutputGenerator;
import com.comcast.meld.generator.TuneOutputGenerator;
import com.comcast.meld.generator.X1StreamingOutputGenerator;
import com.comcast.meld.schema.TrickPlayAndTune;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMap;
import gobblin.configuration.State;
import gobblin.writer.SimpleDataWriter;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;

public class X1StreamingDataWriter extends SimpleDataWriter {
    private static final Logger LOG = Logger.getLogger(X1StreamingDataWriter.class);

    private static final ImmutableMap<String, X1StreamingOutputGenerator> outputGeneratorMap;
    private static final ObjectMapper objectMapper;
    static {
        outputGeneratorMap = ImmutableMap
                .<String, X1StreamingOutputGenerator>builder()
                .put("trickplay", new TrickPlayOutputGenerator())
                .put("tune", new TuneOutputGenerator())
                .build();
        objectMapper = new ObjectMapper();
        objectMapper.registerSubtypes(TrickPlayAndTune.class);
    }

    public X1StreamingDataWriter(X1StreamingWriterBuilder builder, State properties) throws IOException {
        super(builder, properties);
    }

    /**
     * Write a source record to the staging file
     *
     * @param genericRecord data record to write
     * @throws IOException if there is anything wrong writing the record
     */
    @Override
    public void write(byte[] genericRecord) throws IOException {
        try {
            Preconditions.checkNotNull(genericRecord);
            final TrickPlayAndTune trickPlayAndTune = objectMapper.readValue((genericRecord), TrickPlayAndTune.class);
            if ( trickPlayAndTune.getEvent().getName().equals("tune") && trickPlayAndTune.getEventStatus().equalsIgnoreCase("FAILURE"))
            {
            	//Skipping the Failure Events For TUNE 
            }
            else
            {
            
            final X1StreamingOutputGenerator x1StreamingOutputGenerator =
                    outputGeneratorMap.get(trickPlayAndTune.getEvent().getName());
            byte[] record = x1StreamingOutputGenerator.getString(trickPlayAndTune).getBytes();
            super.write(record);
            }
        
        } catch (RuntimeException | JsonParseException e) {
            LOG.error(e.getCause());
        }
    }
}
