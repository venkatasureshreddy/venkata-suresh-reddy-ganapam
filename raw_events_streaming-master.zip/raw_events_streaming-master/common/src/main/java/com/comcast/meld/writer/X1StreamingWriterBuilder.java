package com.comcast.meld.writer;

import gobblin.configuration.State;
import gobblin.writer.DataWriter;
import gobblin.writer.SimpleDataWriterBuilder;

import java.io.IOException;

public class X1StreamingWriterBuilder extends SimpleDataWriterBuilder {

    @Override
    public DataWriter<byte[]> build() throws IOException {
        return new X1StreamingDataWriter(this, this.destination.getProperties());
    }

    //Overriding this method to avoid partitioning for pipe line delimiter output.
    @Override
    protected String getPartitionedFileName(State properties, String originalFileName) {

        return originalFileName;
    }
}
