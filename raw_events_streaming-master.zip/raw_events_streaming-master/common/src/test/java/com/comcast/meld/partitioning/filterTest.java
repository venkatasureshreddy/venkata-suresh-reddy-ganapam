package com.comcast.meld.partitioning;

import org.junit.Test;

/**
 * Created by bowenzheng on 8/24/17.
 */
public class filterTest {

    @Test
    public void stringFilter(){

        String android="cDVR-X2-Android";

        if(android.equalsIgnoreCase("cdvr-x2-android")){
            System.out.println("Get valid app name");
        }else{
            System.out.println("Not same");
        }

    }

    public static void main(String[] args) {}{
        stringFilter();
    }



}
