package com.comcast.meld.partitioning;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.log4j.Logger;
import org.junit.Test;

import java.io.*;
import java.net.URISyntaxException;
import java.net.URL;

import static org.junit.Assert.fail;

/**
 * Created by michaelfagan on 1/3/17.
 */
public class JsonEventPartitionerTest {
  private static final Logger LOG = Logger.getLogger(JsonEventPartitionerTest.class);
  private JsonEventPartitioner partitioner = new JsonEventPartitioner();
  @Test
  public void testGood() throws IOException {
     try (BufferedReader reader = new BufferedReader( new FileReader( getFile("json_good.txt")))) {
       String line = reader.readLine();

       while (line != null) {
         GenericRecord partition = partitioner.partitionForRecord(line.getBytes());
         if ( JsonEventPartitioner.MALFORMED_TIME.equals(partition.get(JsonEventPartitioner.DAY_ID))) {
           fail( "found malformed time");
         }
         line = reader.readLine();
       }
     }
  }

  @Test
  public void testBad() throws IOException {
    try (BufferedReader reader = new BufferedReader( new FileReader( getFile("json_bad.txt")))) {
      String line = reader.readLine();

      while (line != null) {
        GenericRecord partition = partitioner.partitionForRecord(line.getBytes());
        if ( !JsonEventPartitioner.MALFORMED_TIME.equals(partition.get(JsonEventPartitioner.DAY_ID))) {
          fail( "found properly formatted time");
        }
        line = reader.readLine();
      }
    }
  }

  private File getFile( String fileName) {
    File data = null;
    try {
      URL url = ClassLoader.getSystemClassLoader().getResource(fileName);
      data = new File(url.toURI());
    } catch (URISyntaxException e) {
      LOG.error(e.getLocalizedMessage(), e);

    }
    return data;
  }
}
