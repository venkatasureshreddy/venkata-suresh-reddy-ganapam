/*
package com.comcast.meld.partitioning;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.text.ParseException;
import java.util.Scanner;

import org.apache.avro.generic.GenericRecord;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;

public class X1StreamingEventPartitionerTest {
	private static final Logger LOG = Logger.getLogger(X1StreamingEventPartitionerTest.class);

	X1StreamingEventPartitioner x1EventPartitioner;
	String body = null;
	String timestampUtc = null;
	String[] jsonInput = null;
	String[] partitionedOutput = null;
	StringBuilder sampleInput = null;
	StringBuilder sampleOutput = null;
	byte[] message = null;

	private boolean setUpFailed = false;

	@Before
	public void setUp() throws Exception {
		x1EventPartitioner = new X1StreamingEventPartitioner();
		sampleInput = new StringBuilder();
		sampleOutput = new StringBuilder();
		Scanner inputReader = null;
		Scanner outputReader = null;
		try {
			outputReader = new Scanner(new FileReader(new File("src/test/resources/sample_output.txt")));
			inputReader = new Scanner(new FileReader(new File("src/test/resources/sampleJson_input.txt")));

			while (outputReader.hasNext() || inputReader.hasNext()) {

				sampleOutput.append(outputReader.nextLine() + "\n");
				sampleInput.append(inputReader.nextLine() + "\n");

			}
			outputReader.close();
			inputReader.close();

		} catch (FileNotFoundException | IllegalStateException e) {
			setUpFailed = true;
			LOG.error("Encountered error while reading the files: " + e.getMessage());
			LOG.error(e.getLocalizedMessage(), e);
		}

		partitionedOutput = sampleOutput.toString().split("\n");
		jsonInput = sampleInput.toString().split("\n");
	}


	// test case for checking the correct input record partitioned into
	// corresponding day_id
	@Test
	public void testPartitionForRecord() {
		StringBuilder observedOutput = new StringBuilder();
		StringBuilder actualOutput = new StringBuilder();
		GenericRecord partition = null;
		for (int i = 0; i < jsonInput.length; i++) {
			message = jsonInput[i].getBytes();
			partition = x1EventPartitioner.partitionForRecord(message);
			observedOutput.append(partition.toString().trim());
			actualOutput.append(partitionedOutput[i].trim());
		}
		assertEquals(actualOutput.toString(), observedOutput.toString());
	}
	
	// test case for generating day_id for a corresponding timestamp
	@Test
	public void testGetEventDayId() throws ParseException {
		if (setUpFailed) {
			assertEquals(true, false);
		}
		String timestampUtc = "1476057600412";
		String result = X1StreamingEventPartitioner.getEventDayId(timestampUtc);
		assertEquals("2016-10-10", result);

	}
	
	// test case for checking an invalid timestamp generating a malformed_event
	@Test
	public void testGetMalformedEventDayId() throws ParseException {
		if (setUpFailed) {
			assertEquals(true, false);
		}
		String timestampUtc = "14570MALFORMED412";
		String result = X1StreamingEventPartitioner.getEventDayId(timestampUtc);
		assertEquals("malformed_event", result);

	}

}
*/
