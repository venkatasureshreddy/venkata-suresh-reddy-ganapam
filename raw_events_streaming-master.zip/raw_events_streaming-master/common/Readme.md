## X1 Common Files/Libraries

### Synopsis
This project will hold all of the common files and libraries needed to run all of projects under x1_streaming

### Installation
Installation should be handled by doing yum install rpmName.  The rpmName can be found on the Jenkins site http://ebdp-po-t003p.sys.comcast.net:8080/
The files should install into /opt/meld/se/x1_streaming/common
